def gcs2bq(client, table_id):
  from google.cloud import bigquery
  client = bigquery.Client()

  table_id = "peterproject-364114.regdata.regdata"

  job_config = bigquery.LoadJobConfig(
      schema=[
        bigquery.SchemaField('responses', 'RECORD', mode='REPEATED',
        fields=(bigquery.SchemaField('context', 'RECORD', mode='NULLABLE',
        fields=(bigquery.SchemaField('pageNumber', 'INTEGER'), bigquery.SchemaField('uri', 'STRING'))),
        bigquery.SchemaField('fullTextAnnotation', 'RECORD', mode='NULLABLE',
        fields=(bigquery.SchemaField('text', 'STRING'), bigquery.SchemaField('pages', 'RECORD', mode='REPEATED',
        fields=(bigquery.SchemaField('blocks', 'RECORD', mode='REPEATED',
        fields=(bigquery.SchemaField('confidence', 'FLOAT'), bigquery.SchemaField('blockType', 'STRING'), bigquery.SchemaField('paragraphs', 'RECORD', mode='REPEATED',
        fields=(bigquery.SchemaField('confidence', 'FLOAT'), bigquery.SchemaField('words', 'RECORD', mode='REPEATED',
        fields=(bigquery.SchemaField('symbols', 'RECORD', mode='REPEATED',
        fields=(bigquery.SchemaField('property', 'RECORD', mode='NULLABLE',
        fields=(bigquery.SchemaField('detectedBreak', 'RECORD', mode='NULLABLE',
        fields=(bigquery.SchemaField('type', 'STRING'))))), bigquery.SchemaField('confidence', 'FLOAT'), bigquery.SchemaField('text', 'STRING'))), bigquery.SchemaField('boundingBox', 'RECORD', mode='NULLABLE',
        fields=(bigquery.SchemaField('normalizedVertices', 'RECORD', mode='REPEATED',
        fields=(bigquery.SchemaField('y', 'FLOAT'), bigquery.SchemaField('x', 'FLOAT'))))), bigquery.SchemaField('confidence', 'FLOAT'), bigquery.SchemaField('property', 'RECORD', mode='REPEATED',
        fields=(bigquery.SchemaField('detectedLanguages', 'RECORD', mode='REPEATED',
        fields=(bigquery.SchemaField('confidence', 'INTEGER'), bigquery.SchemaField('languageCode', 'STRING'))))))), bigquery.SchemaField('boundingBox', 'RECORD', mode='NULLABLE',
        fields=(bigquery.SchemaField('normalizedVertices', 'RECORD', mode='REPEATED',
        fields=(bigquery.SchemaField('y', 'FLOAT'), bigquery.SchemaField('x', 'FLOAT'))))), bigquery.SchemaField('boundingBox', 'RECORD', mode='NULLABLE',
        fields=(bigquery.SchemaField('normalizedVertices', 'RECORD', mode='REPEATED',
        fields=(bigquery.SchemaField('y', 'FLOAT'), bigquery.SchemaField('x', 'FLOAT'))))))))),
        bigquery.SchemaField('height', 'INTEGER'), bigquery.SchemaField('width', 'INTEGER'), bigquery.SchemaField('confidence', 'FLOAT'), bigquery.SchemaField('property', 'RECORD', mode='REPEATED',
        fields=(bigquery.SchemaField('detectedLanguages', 'RECORD', mode='REPEATED',
        fields=(bigquery.SchemaField('confidence', 'FLOAT'), bigquery.SchemaField('languageCode', 'STRING'))))))))))),
        bigquery.SchemaField('inputConfig', 'RECORD', mode='NULLABLE', 
        fields=(bigquery.SchemaField('mimeType', 'STRING'), bigquery.SchemaField('gcsSource', 'RECORD', mode='NULLABLE',
        fields=(bigquery.SchemaField('uri', 'STRING')))))

      ],
      source_format=bigquery.SourceFormat.NEWLINE_DELIMITED_JSON,
  )
  uri = "gs://forresulta06/pdf_resulteoutput-1-to-2.json"

  load_job = client.load_table_from_uri(
      uri,
      table_id,
      location="US",
      job_config=job_config,
  )

  load_job.result()

  destination_table = client.get_table(table_id)
  print("Loaded {} rows.".format(destination_table.num_rows))